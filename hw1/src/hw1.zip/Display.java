public class Display {
    public static void main(String[] args){
        System.out.println("Welcome to Java, Learning Java Now");
        System.out.println("Programming is fun");

        System.out.println("The result of equation:"+(7.5*6.5-4.5*3)/(47.5-5.5));
    }
}
