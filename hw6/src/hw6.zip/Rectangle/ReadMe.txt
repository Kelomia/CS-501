The RectangleTest.java has two loop, the outsider one let user input the Base-Rectangle info,
th inner one let user input the Test-Rectangle info.

It will begin with ask user to input the Base-R info and show what user input, then ask user to
 input the Test-R info and show what just input. And show their location condition,
 contain center/ contain rectangle/ overlap.

Then user can choose change the base-rectangle info or not, so as Quit.(End inner loop)
The will ask to Quit or change the base-rectangle.(End outter loop)