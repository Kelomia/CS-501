/*
    @author: Zimu Jiao
    HW6-CS501
    
	10.13
    Check input if negative.
	Consist of 3 loops, outer one, middle one to enter base rectangle(may be combine this two), inner loop for test rectangles to be checked for all 
	four of inclusion, overlap, abutment and distincions to the base rectangle. It's possible more than one of these conditions exist.
	The program should be structered at the first, base rectangle once in every repear loop, not repeat entered again.
	Every time the new test rectangles the new shapes should be compared to the same base rectangle entered first.
	All 4 tests should be done automatically, don't ask user which tests to make.
	Few games ask the user if they should report these interactions. The program proceeds appropriately by showing their effects.
	
	11.1/12.5
	Check if the Triangle is valid, a+b>c.
    
*/
package Rectangle;

interface Rectangle{
}